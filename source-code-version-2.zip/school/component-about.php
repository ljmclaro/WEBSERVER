    <!-- About Start -->
    <div class="container-fluid bg-light overflow-hidden pt-5 px-lg-0">
        <div class="container about px-lg-0">
            <div class="row g-0 mx-lg-0">
                <div class="col-lg-6 ps-lg-0 wow fadeIn" data-wow-delay="0.1s" style="min-height: 400px;">
                    <div class="position-relative h-100">
                        <img class="img-fluid h-100" src="img/psu/dr-roy-ferrer.jpg" style="position: absolute;right: 0px; object-fit: contain;float: right;border-radius: 20%;" alt="">
                    </div>
                </div>
                <div class="col-lg-6 about-text py-5 wow fadeIn" data-wow-delay="0.5s">
                    <div class="p-lg-5 pe-lg-0">
                        <p>
                            Recognizing its mandate of providing quality education and services to its stakeholders, Pangasinan State University – Urdaneta City Campus has been and continues to be of service to the community. Since its establishment, PSU Urdaneta persists to be a quality service provider in higher education, through the hard work, perseverance, and wisdom of the administration, faculty, and staff.
                            <br/>
                            Dubbed as the Home of the Topnotchers, the Pangasinan State University – Urdaneta City Campus has produced a number of licensure examination topnotchers in its board programs throughout its operations. This is a testament to the quality education that the campus offers to its students and its continuous growth and improvement. Moreover, its consistently high board examination performance is a proof that PSU Urdaneta City provides the best service to its clients.
                            <br/>
                            PSU – Urdaneta City Campus has always been committed in providing quality service to its students, faculty, staff, community partners, and various stakeholders. Driven by the Vision and Mission of the University, PSU – Urdaneta City continues to improve its operations to give the best services to all. Thus, exposing ourselves in quality assurance mechanisms ensures that this brand of quality service continues to strengthen.<br/>
                            With this, the Pangasinan State University – Urdaneta City Campus family welcomes all of you to witness our actions and achievements!
                        </p>
                        <h1 class="text-primary">DR. ROY C. FERRER</h1>
                        <h6 class="mb-4">CAMPUS EXECUTIVE DIRECTOR</h6>
                    </div>
                </div>
            </div>
        </div>
        <div class="container-xxl py-5">
            <div class="container">
                <h1 class="text-primary">History</h1>
                <h6 class="mb-4">A quick history of PSU-Urdaneta</h6>
                <p>
                    PSU-Urdaneta started as an offshoot of Asingan Campus. It was originally established as a satellite of the said campus before it assumed the status of a full-fledged campus.
                    <br/>
                    <br/>
                    In 1981, Asingan Campus offered additional degree programs in Engineering and Architecture. Phenomenal increase in enrolment ensued. This necessitated the establishment of Urdaneta satellite in order to accommodate the growing number of students in the following years. In view of this, Dr. Asanion, who was the Dean of Asingan Campus during that time, initiated the establishment of satellite campus in the City of Urdaneta. The plan materialized with the cooperation of then Mayor Amadeo Perez Jr. and other concerned government agencies.
                    <br/>
                    <br/>
                    Before long, a move to separate Urdaneta campus as from its mother campus was initiated by the faculty of Engineering. To this end, the assistance of the Sangguniang Bayan of Urdaneta was sought. Board Resolution No. 82, s 1989 was approved and took into effect on August 1, 1989, thereby turning this formerly extension campus into a full-fledged campus.
                    <br/>
                    <br/>
                    In 2005, under the administration of then President Rodolfo V. Asanion, Eastern cluster comprising three campuses namely Asingan, Sta. Maria and Urdaneta was instituted. In this setup, each of the campuses was treated as satellite of the Cluster. During this time, this campus came to be known as “PSU-Eastern Cluster Urdaneta Satellite.” This setup was dissolved in 2008, and the three satellite campuses operated again as independent of one another, each as a standard campus.
                    <br/>
                    <br/>
                    This Campus which was formerly known as College of Engineering, Architecture and Technology metamorphosed into a strong and robust campus. With a view to helping more clienteles, it broadened its services by way of offering additional degree programs like BS Mathematics, Bachelor of Arts in English Language, and Teacher Education.
                    <br/>
                    <br/>
                    Driven by its commitment to deliver quality education, PSU-Urdaneta continues to grab attention in the educational arena.
                </p>
            </div>
        </div>
        <div class="container-xxl py-5">
            <div class="row">
                <div class="col-12 bg-white mb-4 p-3">
                    <h1 class="text-primary text-center">Vision</h1>
                    <p class="text-center">
                        To be a leading industry-driven State University in the ASEAN region by 2030
                    </p>
                </div>
                <div class="col-12 bg-white mb-4 p-3">
                    <h1 class="text-primary text-center">Mission</h1>
                    <p class="text-center">
                        The Pangasinan State University, shall provide a human-centric, resilient, and sustainable academic environment to produce dynamic, responsive, and future-ready individuals capable of meeting the requirements of the local and global communities and industries.
                    </p>
                </div>
                <div class="col-12 bg-white mb-4 p-3">
                    <h1 class="text-primary text-center">Guiding Philosophy</h1>
                    <p class="text-center">
                        The Pangasinan State University's leadership adheres to the Filipino education is geared towards better citizenship and livelihood and the United Nation's declaration that EDUCATION FOR ALL giving ACCESS to quality education.
                    </p>
                </div>
                <div class="col-12 bg-white p-3">
                    <h1 class="text-primary text-center">CORE VALUES</h1>
                    <p style="display: block;margin: auto;max-width: 400px;letter-spacing: 1;">
                        <span class="text-primary" style="font-size: 20px;font-weight: bold;">A</span>ccountability and Transparency<br/>
                        <span class="text-primary" style="font-size: 20px;font-weight: bold;">C</span>credibility and Integrity<br/>
                        <span class="text-primary" style="font-size: 20px;font-weight: bold;">C</span>competence and Commitment to Achieve<br/>
                        <span class="text-primary" style="font-size: 20px;font-weight: bold;">E</span>xcellence in Service Delivery<br/>
                        <span class="text-primary" style="font-size: 20px;font-weight: bold;">S</span>ocial and Environmental Responsiveness<br/>
                        <span class="text-primary" style="font-size: 20px;font-weight: bold;">S</span>pitituality
                    </p>
                </div>
            </div>
        </div>
    </div>