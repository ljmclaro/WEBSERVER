    <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
        <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div>

    <div class="container-fluid bg-dark p-0">
        <div class="row gx-0 d-none d-lg-flex">
            <div class="col-lg-7 px-5 text-start">
                <div class="h-100 d-inline-flex align-items-center me-4">
                    <small class="fa fa-map-marker-alt me-2 text-white"></small>
                    <small class="text-white">San Vicente, Urdaneta, Philippines</small>
                </div>
                <div class="h-100 d-inline-flex align-items-center">
                    <small class="fa fa-phone-alt me-2 text-white"></small>
                    <small class="text-white">(075) 632 2559</small>
                </div>
            </div>
            <div class="col-lg-5 px-5 text-end">
                <div class="h-100 d-inline-flex align-items-center mx-n2">
                    <a class="btn btn-square btn-link rounded-0 border-0 border-end border-secondary" target="_blank" href="https://www.facebook.com/psuurdofficial">
                        <i class="fab fa-facebook-f text-white"></i>
                    </a>
                    <a class="btn btn-square btn-link rounded-0 border-0 border-end border-secondary" target="_blank" href="https://twitter.com/PSUmainOfficial">
                        <i class="fab fa-twitter text-white"></i>
                    </a>
                    <a class="btn btn-square btn-link rounded-0 border-0 border-end border-secondary" target="_blank" href="https://www.linkedin.com/company/psumainofficial/">
                        <i class="fab fa-linkedin-in text-white"></i>
                    </a>
                    <a class="btn btn-square btn-link rounded-0" target="_blank" href="https://www.instagram.com/psumainofficial/">
                        <i class="fab fa-instagram text-white"></i>
                    </a>
                </div>
            </div>
        </div>
    </div>