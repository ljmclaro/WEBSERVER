
<?php include "component-meta-data.php"; ?>

<body>

    <?php include "component-topbar.php"; ?>

    <?php include "component-navbar.php"; ?>

    <img class="w-100" src="img/psu/psuschool.jpg"/>

    <div class="pb-5">
        <img style="display: block;margin: 100px auto 0px auto;width: 300px;" src="img/psu/logo-psu-com-eng.png"/>
        <h1 class="text-center text-primary">Welcome to Computer Engineering Department</h1>
    </div>

    <?php include "component-about.php"; ?>

    <?php include "component-services.php"; ?>


    <?php include "component-contact-us.php"; ?>


    <?php include "component-footer.php"; ?>

    <a href="#" class="btn btn-lg btn-primary btn-lg-square rounded-circle back-to-top"><i class="bi bi-arrow-up"></i></a>

    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/counterup/counterup.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/isotope/isotope.pkgd.min.js"></script>
    <script src="lib/lightbox/js/lightbox.min.js"></script>

    <!-- UI Javascript -->
    <script src="js/main.js"></script>
</body>

</html>