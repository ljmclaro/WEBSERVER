<nav class="navbar navbar-expand-lg navbar-light sticky-top p-0 bg-primary" style="background-image: url('img/psu/logo-psu-cover.png');background-repeat: no-repeat;background-size: cover;background-position: center;">
    <a href="index.html" class="navbar-brand d-flex align-items-center border-end px-4 px-lg-5">
        <img class="psu-logo-desktop" style="height: 60px;" src="img/psu/logo-psu-with-text-fixed.png" />
        <img class="psu-logo-mobile" style="height: 60px;" src="img/psu/logo-psu.png" />
    </a>
    <button type="button" class="navbar-toggler me-4 bg-white" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarCollapse">
        <div class="navbar-nav ms-auto p-4 p-lg-0">
            <a href="index.php" class="nav-item nav-link text-white">Home</a>
            <a href="about.php" class="nav-item nav-link text-white">About Us</a>
            <a href="administration.php" class="nav-item nav-link text-white">Administration</a>
            <a target="_blank" href="https://www.facebook.com/icpep.psu" class="nav-item nav-link text-white">Page</a>
        </div>
        <a target="_blank" href="https://drive.google.com/drive/u/0/home" class="btn btn-primary rounded-0 py-4 px-lg-5 d-none d-lg-block">Upload<i class="fa fa-upload ms-3"></i></a>
    </div>
</nav>
<style type="text/css">
    @media only screen and (max-width: 600px) {
        .psu-logo-desktop { display: none; }
        .psu-logo-mobile { display: block; }
    }
    @media only screen and (min-width: 601px) {
        .psu-logo-desktop { display: block; }
        .psu-logo-mobile { display: none; }
    }
</style>